/*
Script changer_style()
*/
function changer_style(){
    var p = document.getElementById('parag1');
    p.style.color="white";
    p.style.backgroundColor="rosyBrown";
    p.style.border="6px dotted teal";
    p.style.padding="30px";
    p.style.width="60%";
    p.style.margin="0 auto";
}
