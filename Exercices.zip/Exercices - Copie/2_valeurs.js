var a = 2;
a = a - 1;
console.log("var a doit être à 1 : " + a);

a++;
console.log("var a doit être à 2 : " + a);

var b = 8;
b += 2;
console.log("var b doit être à 10 : " + b);

var c = a + b * b;
console.log("var c doit être à 102 : " + c);

var d = a * b + b;
console.log("var d doit être à 30 : " + d);

var e = a * (b + b);
console.log("var e doit être à 40 : " + e);

var f = a * b / a;
console.log("var f doit être à 10 : " + f);

var g = b / a * a;
console.log("var g doit être à 10 : " + f);