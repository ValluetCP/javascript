//var prenom = prompt("Entrez votre prénom");
// alert("Bonjour, " + prenom);

// var saisie = prompt("Entrez un nombre");// nb est de type chaine
// var nb = Number(saisie); // nb est de type nombre

// var nb1 = Number(prompt("Entrez un nombre : ")); // nb1 est de type nombre

var nom = prompt("Entrez votre nom : ");
var prenom = prompt("Entrez votre prénom : ");
alert("Bonjour, " + prenom + " " + nom);